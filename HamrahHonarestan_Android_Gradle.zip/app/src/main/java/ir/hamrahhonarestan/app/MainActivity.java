package ir.hamrahhonarestan.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.view.View;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); WebView web = new WebView(this); web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient()); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setAllowFileAccess(true); setContentView(web); web.loadUrl("file:///android_asset/index.html"); }
 @Override public void onBackPressed() { setContentView(getWindow().getDecorView()); super.onBackPressed(); }
}
